import React from 'react';

const AcercaDe = () => {
	return (
		<div>
			<h2>Acerca de</h2>
			<p>Hola me llamo Carlos</p>
		</div>
	);
}
 
export default AcercaDe;