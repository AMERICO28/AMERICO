import React from 'react';

const Error404 = () => {
	return (
		<div>
			<h2>Error 404</h2>
			<p>La pagina que buscas no existe o fue cambiada de lugar.</p>
		</div>
	);
}
 
export default Error404;