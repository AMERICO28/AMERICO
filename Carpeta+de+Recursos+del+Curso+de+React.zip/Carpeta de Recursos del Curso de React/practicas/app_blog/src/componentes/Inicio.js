import React from 'react';

const Inicio = () => {
	return (
		<div>
			<h2>Página de Inicio</h2>
			<p>Esta es la página principal de nuestro sitio.</p>
		</div>
	);
}
 
export default Inicio;