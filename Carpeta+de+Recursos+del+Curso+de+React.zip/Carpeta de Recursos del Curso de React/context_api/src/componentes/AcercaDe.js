import React from 'react';
import Controles from './Controles';

const AcercaDe = () => {
	return (
		<div>
			<h2>Acerca de</h2>
			<p>Hola me llamo Carlos!</p>
			<Controles />
		</div>
	);
}
 
export default AcercaDe;