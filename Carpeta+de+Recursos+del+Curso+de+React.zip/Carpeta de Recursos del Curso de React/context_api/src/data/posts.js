const posts = [
	{id: 1, titulo: 'Articulo #1', texto: 'Este es el texto de mi primer articulo'},
	{id: 2, titulo: 'Articulo #2', texto: 'Este es el texto de mi segundo articulo'},
	{id: 3, titulo: 'Articulo #3', texto: 'Este es el texto de mi tercer articulo'}
];

export default posts;