import React from 'react';

const Blog = () => {
	return (
		<div>
			<h1>Blog</h1>
			<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis repellendus recusandae quo! Iure praesentium reiciendis qui possimus velit! Mollitia eveniet vel dolorum molestiae harum odit saepe beatae qui iste natus.</p>
		</div>
	);
}
 
export default Blog;